-- Addition for 2.7.6
UPDATE `{tbl_prefix}config` SET value = 'cb_video_js.php' WHERE name = 'player_file';
UPDATE `{tbl_prefix}config` SET value = 'cb_video_js' WHERE name = 'player_dir';

