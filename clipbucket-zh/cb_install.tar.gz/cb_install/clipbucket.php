<?php

/**
 * All Details about ClipBucket 
 * Software Release version, authors are
 * defined in this file, please do not edit this
 *
 * 
 * NOTE : EDITING THIS FILE MAY CASUE YOUR CLIPBUCKET UPDATER NOT TO WORK PROPERLY
 */
 
 define("ClipBucket","ClipBucket - Open Source Media Sharing Script by Arslan Hassan");
 define("VERSION","2.8");
 define("STATE","STABLE");
 define("REV","3354");
 define("RELEASED","21-10-2015");
 define("AUTHORS","ARSLAN HASSAN,FAWAZ TAHIR,FAHAD ABBAS,SAQIB RAZZAQ");

?>